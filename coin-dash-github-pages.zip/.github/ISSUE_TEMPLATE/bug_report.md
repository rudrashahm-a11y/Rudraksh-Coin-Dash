---
name: Bug report
about: Report something that is not working correctly
title: "[Bug] "
labels: bug
assignees: ''
---

## What happened?

## Steps to reproduce

## Browser/device

## Screenshots
